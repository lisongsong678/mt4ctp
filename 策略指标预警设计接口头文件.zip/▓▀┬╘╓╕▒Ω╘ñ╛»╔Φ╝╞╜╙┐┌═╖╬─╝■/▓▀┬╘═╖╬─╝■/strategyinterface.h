#ifndef SINGLEIDSTRAINTERFACEFUT_H
#define SINGLEIDSTRAINTERFACEFUT_H

#include <QObject>
#include "pluginsharedatastruct.h"

#define StrategyInterface_IID "plugin.strategyinterface"



class StrategyInterface
{
public:
    virtual ~StrategyInterface(){}
    virtual QString getFileName() = 0;
    virtual strategyRet funStrategyCal(QHash<QString,QHash<QString,QHash<int,QVector<double>>>> &indicatordat,KLine *p,QVariant &medbuf,QVector<int> &barscountAtPrevTickList,
                                       TThostFtdcMoneyType	Balance,TThostFtdcMoneyType	CurrMargin,TThostFtdcMoneyType	Available,TThostFtdcMoneyType AllFrozenMargin,
                                       QList<pendingorder> &pendList,QList<postotalfieldfuture> &longposList,QList<postotalfieldfuture> &shortposList,
                                       QList<traderecord> &lastBuyOpenRecList,QList<traderecord> &lastSellOpenRecList,
                                       QString straid,TThostFtdcVolumeMultipleType	VolumeMultiple,TThostFtdcPriceType	PriceTick,TThostFtdcRatioType	OpenRatioByMoney,
                                       TThostFtdcMoneyType	OpenRatioByVolume,TThostFtdcRatioType	CloseRatioByMoney,TThostFtdcMoneyType	CloseRatioByVolume,
                                       TThostFtdcRatioType	CloseTodayRatioByMoney,TThostFtdcRatioType	CloseTodayRatioByVolume,
                                       CThostFtdcDepthMarketDataField &tickdata) = 0;
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(StrategyInterface, StrategyInterface_IID)
QT_END_NAMESPACE

#endif // SINGLEIDSTRAINTERFACEFUT_H
