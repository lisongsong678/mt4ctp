#ifndef MULTIIDSTRAINTERFACE_H
#define MULTIIDSTRAINTERFACE_H

#include <QObject>
#include "pluginsharedatastruct.h"

#define StrategyInterfaceMix_IID "plugin.strategyinterfacemix"



class StrategyInterfaceMix
{
public:
    virtual ~StrategyInterfaceMix(){}
    virtual QString getFileName() = 0;
    //���в����������ȫ�г�
    virtual strategyRet funStrategyCal(QHash<QString,struct InstrumentOrder > &futuredata,QHash<QString,struct optionInstrInfo > &optiondata,QVariant &medbuf,
                                       TThostFtdcMoneyType	Balance,TThostFtdcMoneyType	CurrMargin,TThostFtdcMoneyType	Available,TThostFtdcMoneyType AllFrozenMargin,
                                       TThostFtdcMoneyType AllCashIn,TThostFtdcMoneyType AllFrozenCashIn,pendingorder *pPendingOrder,int PendingOrderSize,
                                       postotalfieldfuture *pPosTotalFutField,int futpostotalsize,postotalfieldoption *pPosTotalOptField,int optpostotalsize,
                                       traderecord *pTradeRecord,int TradeRecordSize,traderecord *pHistoryTradeRecord,int HistoryTradeRecordSize,
                                       QString straid,CThostFtdcDepthMarketDataField &tickdata) = 0;
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(StrategyInterfaceMix, StrategyInterfaceMix_IID)
QT_END_NAMESPACE

#endif // MULTIIDSTRAINTERFACE_H
