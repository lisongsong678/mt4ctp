#ifndef SINGLEIDSTRAINTERFACEOPT_H
#define SINGLEIDSTRAINTERFACEOPT_H

#include <QObject>
#include "pluginsharedatastruct.h"

#define StrategyInterfaceOpt_IID "plugin.strategyinterfaceopt"



class StrategyInterfaceOpt
{
public:
    virtual ~StrategyInterfaceOpt(){}
    virtual QString getFileName() = 0;
    virtual strategyRet funStrategyCal(QHash<QString,QHash<QString,QHash<int,QVector<double>>>> &indicatordat,KLineOption *p,QVariant &medbuf,QVector<int> &barscountAtPrevTickList,
                                       TThostFtdcMoneyType	Balance,TThostFtdcMoneyType	CurrMargin,TThostFtdcMoneyType	Available,TThostFtdcMoneyType AllFrozenMargin,
                                       TThostFtdcMoneyType AllCashIn,TThostFtdcMoneyType AllFrozenCashIn,QList<pendingorder> &pendList,QList<postotalfieldoption> &longposList,
                                       QList<postotalfieldoption> &shortposList,QList<traderecord> &lastBuyOpenRecList,QList<traderecord> &lastSellOpenRecList,
                                       QString straid,TThostFtdcVolumeMultipleType	VolumeMultiple,TThostFtdcPriceType	PriceTick,TThostFtdcRatioType	OpenRatioByMoney,
                                       TThostFtdcRatioType	OpenRatioByVolume,TThostFtdcRatioType	CloseRatioByMoney,TThostFtdcMoneyType	CloseRatioByVolume,
                                       TThostFtdcRatioType	CloseTodayRatioByMoney,TThostFtdcMoneyType	CloseTodayRatioByVolume,
                                       TThostFtdcRatioType	StrikeRatioByMoney,TThostFtdcRatioType	StrikeRatioByVolume,
                                       CThostFtdcDepthMarketDataField &tickdata) = 0;
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(StrategyInterfaceOpt, StrategyInterfaceOpt_IID)
QT_END_NAMESPACE

#endif // SINGLEIDSTRAINTERFACEOPT_H
