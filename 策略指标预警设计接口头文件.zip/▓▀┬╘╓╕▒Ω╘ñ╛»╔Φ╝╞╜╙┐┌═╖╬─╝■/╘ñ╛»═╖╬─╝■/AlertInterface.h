#ifndef ALERTINTERFACE_H
#define ALERTINTERFACE_H
#include <QObject>
#define AlertInterface_IID "plugin.alertinterface"
#include "pluginsharedatastruct.h"
//��װĿ¼alert
class AlertInterface
{
public:
    virtual ~AlertInterface(){}
    virtual QString getFileName() = 0;
    virtual QList<alertRet> funAlertCal(QHash<QString,QHash<QString,QHash<int,QVector<double>>>> &indicatordat,QVariant &medbuff) = 0;
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(AlertInterface, AlertInterface_IID)
QT_END_NAMESPACE

#endif // ALERTINTERFACE_H
