#ifndef ALERTINTERFACEOPT_H
#define ALERTINTERFACEOPT_H

#include <QObject>
#define AlertInterfaceOpt_IID "plugin.alertinterfaceopt"
#include "pluginsharedatastruct.h"
//��װĿ¼alertopt
class AlertInterfaceOpt
{
public:
    virtual ~AlertInterfaceOpt(){}
    virtual QString getFileName() = 0;
    virtual QList<alertRet> funAlertCal(QHash<QString,QHash<QString,QHash<int,QVector<double>>>> &indicatordat,QVariant &medbuff) = 0;
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(AlertInterfaceOpt, AlertInterfaceOpt_IID)
QT_END_NAMESPACE

#endif // ALERTINTERFACEOPT_H
