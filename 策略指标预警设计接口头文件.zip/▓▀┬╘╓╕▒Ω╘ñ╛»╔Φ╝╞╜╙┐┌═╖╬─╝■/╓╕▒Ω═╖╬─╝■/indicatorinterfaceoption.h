#ifndef INDICATORINTERFACEOPTION_H
#define INDICATORINTERFACEOPTION_H

#include <qcustomplot.h>
#include "pluginsharedatastruct.h"

#define IndicatorInterfaceOption_IID "plugin.indicatorinterfaceoption"


struct indicatorParamOption
{
    QPair<QStringList,QVector<double>> nameOrParam;
};

struct abountIndiPlotOption
{
    QPair<QString,QHash<QString,QVector<QCPAbstractPlottable *> > > indicatorplots;
    QPair<QCPAxisRect *,bool> updatAxisrect;
};


class IndicatorInterfaceOption
{
public:
    virtual ~IndicatorInterfaceOption(){}
    virtual QString getFileName() = 0;
    virtual indicatorParamOption initIndicatorBuffer() = 0;//��ȡָ�������buffer����Լ��������
    virtual void calIndicatorData(KLineOption &kl,int period,QVector<double> &inputgram,QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,bool isallcal) = 0;//����ָ����������� //a164
    virtual struct abountIndiPlotOption initUiPlot(QCustomPlot *customplot,QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,QVector<double> &inputpram,
                                                   int axisRectIndex,QCPMarginGroup *group) = 0;//��ʼ��ָ�����ʾ��񲢷��ظ���plot��ָ��
    virtual void updatePlot(QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,QHash<QString,QVector<QCPAbstractPlottable *> > &plotOfIndicator,QVector<double> &inputgram,
                            int period,bool isallupdated) = 0;//����plot
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(IndicatorInterfaceOption, IndicatorInterfaceOption_IID)
QT_END_NAMESPACE

#endif // INDICATORINTERFACEOPTION_H
