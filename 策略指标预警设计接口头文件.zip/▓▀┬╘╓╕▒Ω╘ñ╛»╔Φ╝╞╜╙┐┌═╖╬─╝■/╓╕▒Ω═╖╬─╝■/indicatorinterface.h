#ifndef INDICATORINTERFACE_H
#define INDICATORINTERFACE_H

#include <qcustomplot.h>
#include "pluginsharedatastruct.h"

#define IndicatorInterface_IID "plugin.indicatorinterface"

struct indicatorParam
{
    QPair<QStringList,QVector<double>> nameOrParam;
};

struct abountIndiPlot
{
    QPair<QString,QHash<QString,QVector<QCPAbstractPlottable *> > > indicatorplots;
    QPair<QCPAxisRect *,bool> updatAxisrect;
};

class IndicatorInterface
{
public:
    virtual ~IndicatorInterface(){}
    virtual QString getFileName() = 0;
    virtual indicatorParam initIndicatorBuffer() = 0;//��ȡָ�������buffer����Լ��������   
    virtual void calIndicatorData(KLine &kl,int period,QVector<double> &inputgram,QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,bool isallcal) = 0;//����ָ����������� //a164
    virtual struct abountIndiPlot initUiPlot(QCustomPlot *customplot,QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,QVector<double> &inputpram,
                                             int axisRectIndex,QCPMarginGroup *group) = 0;//��ʼ��ָ�����ʾ��񲢷��ظ���plot��ָ��
    virtual void updatePlot(QHash<QString,QHash<int,QVector<double>>> &indicatorbuffer,QHash<QString,QVector<QCPAbstractPlottable *> > &plotOfIndicator,QVector<double> &inputgram,
                            int period,bool isallupdated) = 0;//����plot
};

QT_BEGIN_NAMESPACE
Q_DECLARE_INTERFACE(IndicatorInterface, IndicatorInterface_IID)
QT_END_NAMESPACE

#endif // INDICATORINTERFACE_H




